package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("diva")
public class Diva implements Cha{
	@Autowired
//	@Qualifier("b")
	private weapon wp;
	public Diva() {
		// TODO Auto-generated constructor stub
		System.out.println("Diva Create");
	}
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		wp.attack();
	}
}
