package test;

import org.springframework.stereotype.Component;

//@Component("b")
public class B implements weapon{
	public B() {
		// TODO Auto-generated constructor stub
		System.out.println("B���� ����");
	}
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		System.out.println("B���� ����");
	}
}
