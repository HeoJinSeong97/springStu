package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("timo")
public class Timo implements Cha{
	@Autowired
//	@Qualifier("a")
	private weapon wp;
	public Timo() {
		// TODO Auto-generated constructor stub
		System.out.println("Timo Create");
	}
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		wp.attack();
	}
}
