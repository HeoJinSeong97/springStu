package test;

public interface weapon {
	void attack();
}
