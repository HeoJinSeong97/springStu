package test;

public interface Cha {
	public void attack();
}
