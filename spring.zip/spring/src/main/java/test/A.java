package test;

import org.springframework.stereotype.Component;

//@Component("a")
public class A implements weapon{
	public A() {
		// TODO Auto-generated constructor stub
		System.out.println("A���� ����");
	}
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		System.out.println("A���� ����");
	}
}
