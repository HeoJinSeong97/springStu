package com.heo.app.common;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

@Service
@Aspect
public class LogAfterAdvice {
	
	@After("PointCut.aPointcut()")
	public void printLog() {
		System.out.println("�׻� ����Ǵ� LogAfterAdvice");
	}
}
