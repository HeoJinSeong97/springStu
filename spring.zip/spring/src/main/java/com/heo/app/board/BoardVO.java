package com.heo.app.board;

import java.util.*;

import org.springframework.web.multipart.MultipartFile;

public class BoardVO {
	private int id;
	   private String title;
	   private String writer;
	   private String content;
	   private Date wdate;
	   private int cnt;
	   private String search;			//검색기능 수행시, 컨테이너가 커멘드 객체 생성
	   private String searchContent; //생성된 객체에 값 추출-세터 자동으로 설정
	   private MultipartFile uplodeFile;
	   
	   
	   
	   public MultipartFile getUplodeFile() {
		return uplodeFile;
	}
	public void setUplodeFile(MultipartFile uplodeFile) {
		this.uplodeFile = uplodeFile;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String getSearchContent() {
		return searchContent;
	}
	public void setSearchContent(String searchContent) {
		this.searchContent = searchContent;
	}
	public int getId() {
	      return id;
	   }
	   public void setId(int id) {
	      this.id = id;
	   }
	   public String getTitle() {
	      return title;
	   }
	   public void setTitle(String title) {
	      this.title = title;
	   }
	   public String getWriter() {
	      return writer;
	   }
	   public void setWriter(String writer) {
	      this.writer = writer;
	   }
	   public String getContent() {
	      return content;
	   }
	   public void setContent(String content) {
	      this.content = content;
	   }
	   public Date getWdate() {
	      return wdate;
	   }
	   public void setWdate(Date wdate) {
	      this.wdate = wdate;
	   }
	   public int getCnt() {
	      return cnt;
	   }
	   public void setCnt(int cnt) {
	      this.cnt = cnt;
	   }
	@Override
	public String toString() {
		return "BoardVO [id=" + id + ", title=" + title + ", writer=" + writer + ", content=" + content + ", wdate="
				+ wdate + ", cnt=" + cnt + "]";
	}
	   
	   

}
