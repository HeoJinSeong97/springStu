package com.heo.app.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.util.StopWatch;

public class AroundAdvice {
	public Object printLog(ProceedingJoinPoint pjp) {
		Object obj = null;;
		try {
			System.out.println("AroundAdvice.. [beford]");
			StopWatch sw = new StopWatch();
			
			sw.start();
			obj = pjp.proceed();
			sw.stop();
			
			System.out.println("AroundAdvice.. [after]");
			System.out.println(pjp.getSignature().getName()+"()�޼����� ����ð�: "+sw.getTotalTimeSeconds());
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}
}
