package com.heo.app.product;

import java.util.List;

public interface productService {
	void insertProduct(productVO vo);
	void updateProduct(productVO vo);
	void deleteProduct(productVO vo);
	productVO getProduct(productVO vo);
	List<productVO> getProductList();
}
