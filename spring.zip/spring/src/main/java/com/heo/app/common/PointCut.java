package com.heo.app.common;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class PointCut {
	
	@Pointcut("execution(* com.heo.app..*Impl.*(..))")
	public void aPointcut() {}
	
	@Pointcut("execution(* com.heo.app..*Impl.get*(..))")
	public void bPointcut() {}
}
