package com.heo.app.user.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import com.heo.app.user.UserVO;


@Repository("userDAO2")
public class UserDAO2 extends JdbcDaoSupport{
	
	@Autowired
	public void setSuperDataSource(DataSource datasource) {
		super.setDataSource(datasource);
	}
	
	public UserDAO2() {
		// TODO Auto-generated constructor stub
		System.out.println("userDAO ������");
	}
	public void insertUser(UserVO vo) {
		String sql = "insert into users values(?,?,?,?)";
		
		getJdbcTemplate().update(sql, vo.getId(), vo.getName(), vo.getPassword(), vo.getRole());
		
		System.out.println("Userinsert����Ϸ�...");
	}
	
	public UserVO getUser(UserVO vo) {
		String sql = "select * from users where id = ? and password=?";
		System.out.println("getusers������");
		Object[] args = {vo.getId(), vo.getPassword()};
		return getJdbcTemplate().queryForObject(sql, args, new UserRowMapper());
	}
	
	
	public List<UserVO> getUserList() {
		String sql = "select * from users";
		System.out.println("usersList������");
		
		return getJdbcTemplate().query(sql, new UserRowMapper());
	}
	
}

class UserRowMapper implements RowMapper{
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserVO data = new UserVO();
		data.setId(rs.getString("id"));
		data.setName(rs.getString("name"));
		data.setPassword(rs.getString("password"));
		data.setRole(rs.getString("role"));
		return data;
	}
}
