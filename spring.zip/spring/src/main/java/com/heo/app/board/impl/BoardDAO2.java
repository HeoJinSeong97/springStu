package com.heo.app.board.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.heo.app.board.BoardVO;


@Repository("boardDAO")
public class BoardDAO2 extends JdbcDaoSupport {
//	jdbcTemplate�� �̿��Ұ��
//	@Autowired
//	private JdbcTemplate jdbcTemplate;
//	-> Bean���� �����صξ���
//	<bean id="jdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate">
//	<property name="dataSource" ref="ds"></property>
//	</bean>
	
//	DataSource�� ����ϱ� ������ �� ����ؾ���.
	@Autowired
	public void setSupertDataSource(DataSource datasource) {
		super.setDataSource(datasource);
	}
	
	public BoardDAO2() {
		// TODO Auto-generated constructor stub
		System.out.println("BoardDAO2 ������..");
		
	}
	
	public void insertBoard(BoardVO vo) {
		System.out.println("insert() ...");
		String sql = "insert into board(title, writer, content) values(?,?,?)";
//		nvl( , ) : null�̸� �ٸ� ������ ����
		System.out.println("insert����");
		getJdbcTemplate().update(sql, vo.getTitle(), vo.getWriter(), vo.getContent());
		
	}
	public void updateBoard(BoardVO vo) {
		System.out.println("update...");
		String sql="update board set title=?, content=? where id=?";
		getJdbcTemplate().update(sql, vo.getTitle(), vo.getContent(), vo.getId());
	}
	
	public void deleteBoard(BoardVO vo) {
		System.out.println("delete...");
		String sql="delete from board where id=?";
//		String sql="delete from board where id between 4 and 17";
		getJdbcTemplate().update(sql, vo.getId());
	}
	
	public BoardVO getBoard(BoardVO vo) {
		System.out.println("getBoard()...");
		String sql="select * from board where id=?";
		
		Object[] args = {vo.getId()};
	
		
		return getJdbcTemplate().queryForObject(sql, args, new BoardRowMapper());
	}
	 public List<BoardVO> getBoardList(BoardVO vo) {
		  String sql="select * from board where title like '%'||?||'%' order by id desc";
	      String sql2="select * from board where content like '%'||?||'%' order by id desc";
	      System.out.println("getBoardList() ������");
	      Object[] args = {vo.getSearchContent()};
	      return getJdbcTemplate().query(sql, args,new BoardRowMapper());
	   }
	 


}
class BoardRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		BoardVO data=new BoardVO();
        data.setCnt(rs.getInt("cnt"));
        data.setContent(rs.getString("content"));
        data.setId(rs.getInt("id"));
        data.setTitle(rs.getString("title"));
        data.setWdate(rs.getDate("wdate"));
        data.setWriter(rs.getString("writer"));
		return data;
	}
	
}

