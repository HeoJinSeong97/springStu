package com.heo.app.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

@Service
@Aspect
public class LogAroundAdvice {

	@Around("PointCut.aPointcut()")
	public Object printLog(ProceedingJoinPoint pjp) {
		Object obj = null;;
		try {
			System.out.println("LogAroundAdvice.. [beford]");
			StopWatch sw = new StopWatch();
			
			sw.start();
			obj = pjp.proceed();
			sw.stop();
			
			System.out.println("LogAroundAdvice.. [after]");
			System.out.println(pjp.getSignature().getName()+"()�޼����� ����ð�: "+sw.getTotalTimeSeconds());
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}
}
