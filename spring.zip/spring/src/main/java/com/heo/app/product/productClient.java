package com.heo.app.product;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class productClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		
		productService ps = (productService)factory.getBean("ProductService");
		
		productVO data = new productVO();
//		data.setName("������");
//		data.setPrice(20000);
//		ps.insertProduct(data);
		
		data.setId(2);
		data = ps.getProduct(data);
		System.out.println("getProduct : " + data);
//		
//		ps.updateProduct(data);
//		ps.deleteProduct(data);
		
		
		List<productVO> list = ps.getProductList();
		for (productVO productVO : list) {
			System.out.println(productVO);
		}
		
		factory.close();
	}

}
