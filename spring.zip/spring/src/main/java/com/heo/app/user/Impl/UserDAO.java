package com.heo.app.user.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.heo.app.common.JDBC;
import com.heo.app.user.UserVO;

@Repository("userDAO")
public class UserDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	public UserDAO() {
		// TODO Auto-generated constructor stub
		System.out.println("userDAO ������");
	}
	public void insertUser(UserVO vo) {
		System.out.println("Userinsert...");
		String sql = "insert into users(id, name, password, role) values(?,?,?,?)";
		conn = JDBC.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getName());
			pstmt.setString(3, vo.getPassword());
			pstmt.setString(4, vo.getRole());
			pstmt.executeUpdate();
			System.out.println("users insert�Ϸ�");
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
	}
	
	public UserVO getUser(UserVO vo) {
		String sql = "select * from users where id = ? and password=?";
		System.out.println("getusers������");
		UserVO data=null;
		conn = JDBC.getConnection();
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				data=new UserVO();
				data.setId(rs.getString("id"));
				data.setPassword(rs.getString("password"));
				data.setName(rs.getString("name"));
				data.setRole(rs.getString("role"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
		return data;
	}
	
	
	public List<UserVO> getUserList() {
		String sql = "select * from users";
		System.out.println("usersList������");
		List<UserVO> datas = new ArrayList<UserVO>();
		conn = JDBC.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				UserVO uv = new UserVO();
				uv.setId(rs.getString("id"));
				uv.setName(rs.getString("name"));
				uv.setPassword(rs.getString("password"));
				uv.setRole(rs.getString("role"));
				datas.add(uv);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
		return datas;
	}
	
}
