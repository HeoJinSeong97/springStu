package com.heo.app.product.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heo.app.product.productService;
import com.heo.app.product.productVO;

@Service("ProductService")
public class PproductServiceImpl implements productService{

	@Autowired
	ProductDAO productDAO;
	
	@Override
	public void insertProduct(productVO vo) {
		// TODO Auto-generated method stub
		productDAO.insertProduct(vo);
	}

	@Override
	public void updateProduct(productVO vo) {
		// TODO Auto-generated method stub
		productDAO.updateProduct(vo);
	}

	@Override
	public void deleteProduct(productVO vo) {
		// TODO Auto-generated method stub
		productDAO.deleteProduct(vo);
	}

	@Override
	public productVO getProduct(productVO vo) {
		// TODO Auto-generated method stub
		return productDAO.getProduct(vo);
	}

	@Override
	public List<productVO> getProductList() {
		// TODO Auto-generated method stub
		return productDAO.getProductList();
	}
	
}
