package com.heo.app.board;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.heo.app.common.JDBC;

public class BoardClient {
	public static void main(String[] args) {
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		
//		Connection conn = JDBC.getConnection();
		
		BoardService bs = (BoardService)factory.getBean("BoardService");
		BoardVO vo = new BoardVO();
//		vo.setTitle("Transaction");
//		vo.setContent("aTransactiona");
//		vo.setWriter("jin");
//		bs.insertBoard(vo);
//		
//
//
//		bs.deleteBoard(vo);
//
//		vo.setId(7);
//		vo.setTitle("banana");
//		bs.updateBoard(vo);
		
		
//		bs.getBoard(vo);
//		
		List<BoardVO> data = bs.getBoardList(vo);
		for (BoardVO v : data) {
			System.out.println(v.toString());
		}
//		
		factory.close();
	}
}
