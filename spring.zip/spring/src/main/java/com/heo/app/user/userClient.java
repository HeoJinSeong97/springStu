package com.heo.app.user;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class userClient {
	public static void main(String[] args) {
		
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
//		XmlWebApplicationContext << ������(Spring)
		
		UserService us = (UserService)factory.getBean("UserService");
		UserVO vo = new UserVO();
		
//		vo.setId("heo3");
//		vo.setName("jiz");
//		vo.setPassword("seong");
//		vo.setRole("USER");
//		us.insertUser(vo);
		vo.setId("admin");
		vo.setPassword("1234");
		vo = us.getUser(vo);
		System.out.print(vo);
		
		
		List<UserVO> datas = us.getUserList();
		for (UserVO userVO : datas) {
			System.out.println(userVO.toString());
		}
		factory.close();
	}
}
