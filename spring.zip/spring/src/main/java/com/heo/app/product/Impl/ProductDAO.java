package com.heo.app.product.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.heo.app.product.productVO;

@Repository("productDAO")
public class ProductDAO extends JdbcDaoSupport{

	@Autowired
	public void setSuperDataSource(DataSource datasource) {
		super.setDataSource(datasource);
	}
	
	public void insertProduct(productVO vo) {
		System.out.println("product insert������");
		String sql = "insert into product(name, price) values(?,?)";
		getJdbcTemplate().update(sql, vo.getName(), vo.getPrice());
	};
	public void updateProduct(productVO vo) {
		System.out.println("product update������");
		String sql = "update product set name = ?, price = ? where id = ?";
		getJdbcTemplate().update(sql, vo.getName(), vo.getPrice(),vo.getId());
	};
	public void deleteProduct(productVO vo) {
		System.out.println("product delete������");
		String sql = "delete from product where id = ?";
		getJdbcTemplate().update(sql, vo.getId());
	};
	public productVO getProduct(productVO vo) {
		System.out.println("product getProduct������");
		String sql = "select * from product where id = ?";
		Object[] args= {vo.getId()};
		return getJdbcTemplate().queryForObject(sql, args, new productRowMapper());
	};
	public List<productVO> getProductList(){
		System.out.println("product getProductList������");
		String sql = "select * from product";
		return getJdbcTemplate().query(sql, new productRowMapper());
	};
}
class productRowMapper implements RowMapper{
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		productVO data = new productVO();
		data.setId(rs.getInt("id"));
		data.setName(rs.getString("name"));
		data.setPrice(rs.getInt("price"));
		return data;
	}
}
