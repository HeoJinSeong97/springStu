package com.heo.app.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.springframework.stereotype.Repository;

import com.heo.app.board.BoardVO;
import com.heo.app.common.JDBC;

//@Repository("boardDAO")
public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	
	public BoardDAO() {
		// TODO Auto-generated constructor stub
		System.out.println("BoardDAO ������..");
	}
	
	public void insertBoard(BoardVO vo) {
		System.out.println("insert ...");
		String sql = "insert into board(title, writer, content) values(?,?,?)";
//		nvl( , ) : null�̸� �ٸ� ������ ����
		conn = JDBC.getConnection();
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getWriter());
			pstmt.setString(3, vo.getContent());
			
			pstmt.executeUpdate();
			System.out.println("insert����Ϸ�");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
		
	}
	public void updateBoard(BoardVO vo) {
		System.out.println("update...");
		String sql="update board set title=?, content=? where id=?";
		conn = JDBC.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getTitle());
			pstmt.setString(2, vo.getContent());
			pstmt.setInt(3, vo.getId());
			
			pstmt.executeUpdate();
			System.out.println("update...end");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
	}
	public void deleteBoard(BoardVO vo) {
		System.out.println("delete...");
		System.out.println("�۹�ȣ..."+vo.getId());
		String sql="delete from board where id=?";
//		String sql="delete from board where id between 4 and 17";
		conn = JDBC.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getId());
			
			pstmt.executeUpdate();
			System.out.println("�����Ϸ�");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
	}
	public BoardVO getBoard(BoardVO vo) {
		BoardVO data = null;
		System.out.println("getBoard...");
		String sql="select * from board where id=?";
		conn = JDBC.getConnection();
		try {
			data = new BoardVO();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getId());
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				data.setId(rs.getInt("id"));
				data.setTitle(rs.getString("title"));
				data.setWriter(rs.getString("writer"));
				data.setContent(rs.getString("content"));
				data.setWdate(rs.getDate("wdate"));
				data.setCnt(rs.getInt("cnt"));
			}
			System.out.println(data.toString());;
			System.out.println("getBoard...����Ϸ�");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			JDBC.disConnection(conn, pstmt);
		}
		
		return data;
	}
	 public List<BoardVO> getBoardList(BoardVO vo) {
	      String sql="select * from board order by id";
	      System.out.println("getBoardList() ������");
	      List<BoardVO> datas=new ArrayList();
	      conn=JDBC.getConnection();
	      try {
	         pstmt=conn.prepareStatement(sql);

	         ResultSet rs=pstmt.executeQuery();
	         while(rs.next()) {
	            BoardVO data=new BoardVO();
	            data.setCnt(rs.getInt("cnt"));
	            data.setContent(rs.getString("content"));
	            data.setId(rs.getInt("id"));
	            data.setTitle(rs.getString("title"));
	            data.setWdate(rs.getDate("wdate"));
	            data.setWriter(rs.getString("writer"));
	            datas.add(data);
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	      finally {
	         JDBC.disConnection(conn, pstmt);
	      }
	      return datas;
	   }

}
