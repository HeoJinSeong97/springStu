package com.heo.app.common;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

import com.heo.app.board.BoardVO;
import com.heo.app.user.UserVO;

@Service
@Aspect
public class LogAdviceReturningAdvice {

	
	@AfterReturning(pointcut = "PointCut.bPointcut()", returning = "reObj")
	public void printLog(JoinPoint jp, Object reObj) {
		System.out.println("LogAfterAdvice ������.. ");
		System.out.println("�۾�: "+jp.getSignature().getName());
		if (reObj instanceof BoardVO) {
			BoardVO vo=(BoardVO)reObj;
			System.out.println(vo.getId()+":"+vo.getTitle());
		} else if(reObj instanceof UserVO){
			UserVO uo = (UserVO)reObj;
			System.out.println(uo.getName()+":"+uo.getRole());
		}else {
			System.out.println("��Ī�Ǵ� Ŭ���� ����");
		}
		System.out.println("==============");
	}
	
}
