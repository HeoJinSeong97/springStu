package com.heo.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.heo.app.user.UserVO;
import com.heo.app.user.Impl.UserDAO;

public class insertRegistController implements Controller{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		UserVO vo = new UserVO();
		UserDAO dao = new UserDAO();
		vo.clear();		
		vo.setId(id);
		vo.setName(name);
		vo.setPassword(password);
		vo.setRole("USER");
		
		UserVO data = dao.getUser(vo);

		ModelAndView mav = new ModelAndView();
		if(data == null){
			dao.insertUser(vo);
			System.out.println("����");
			mav.setViewName("redierct:login.jsp");
			return mav;
		}else{
			System.out.println("����");
			mav.setViewName("redierct:regist.jsp");
			return mav;
		
		}
	}
}
