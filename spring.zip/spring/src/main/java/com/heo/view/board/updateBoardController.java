package com.heo.view.board;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;

//@Controller
public class updateBoardController{
	
//	@RequestMapping(value = "/updateBoard.do")
	public String updateBoard(BoardVO vo, BoardDAO dao) throws Exception {
		// TODO Auto-generated method stub

		dao.updateBoard(vo);

		System.out.println("updateController");
		return "redirect:getBoardList.do";
	}
}
