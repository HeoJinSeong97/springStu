package com.heo.view.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.heo.app.user.UserVO;
import com.heo.app.user.Impl.UserDAO;

public class UserListController implements Controller{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserVO vo = new UserVO();
		UserDAO dao = new UserDAO();
		List<UserVO> userlist = dao.getUserList();
//		HttpSession session = request.getSession();
//		session.setAttribute("data", userlist);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("data", userlist);
		if (userlist != null) {
			mav.setViewName("getUserList");
			return mav;			
		} else {
			mav.setViewName("redierct:login.jsp");
			return mav;			

		}
	}
}
