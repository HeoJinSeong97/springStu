package com.heo.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;

//@Controller
public class GetBoardController {
//	@RequestMapping("/getBoard.do")
	public ModelAndView handleRequest(BoardVO vo, BoardDAO dao, ModelAndView mav) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("getBoardController");

		BoardVO v = dao.getBoard(vo);

		mav.addObject("v", v);
		mav.setViewName("getBoard.jsp");
		return mav;
	}
}
