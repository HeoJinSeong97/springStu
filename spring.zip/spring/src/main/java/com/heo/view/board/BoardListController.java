package com.heo.view.board;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;
//@Controller
public class BoardListController {

//	@RequestMapping(value = "/getBoardList.do")
	public ModelAndView getBoardList(BoardVO vo, BoardDAO dao, ModelAndView mav) throws Exception {
		System.out.println("boardlist");
		List<BoardVO> boardList = dao.getBoardList(vo);
		
//		HttpSession session = request.getSession();
//		session.setAttribute("data", boardList);
		
		mav.addObject("data", boardList);
		mav.setViewName("getBoardList.jsp");
		
		return mav;
	}
}
