package com.heo.view.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


import com.heo.app.user.UserVO;
import com.heo.app.user.Impl.UserDAO;

//@Controller
public class LoginController{
	
//	@RequestMapping(value ="/login.do")
	public String handleRequest(UserVO vo, UserDAO dao) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("loginController");

        UserVO data=dao.getUser(vo);

        if(data!=null){
        	System.out.print("데이터있음");
        	return "redirect:getBoardList.do";

        }
        else{
        	return "login.jsp";

        }
	}
}
