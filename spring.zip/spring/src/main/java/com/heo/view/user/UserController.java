package com.heo.view.user;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.heo.app.user.UserVO;
import com.heo.app.user.Impl.UserDAO;

@Controller
public class UserController {

//	post방식으로 요구한다면 아래의 함수를 실행하라.
	@RequestMapping(value ="/login.do", method = RequestMethod.POST)
	public String handleRequest(UserVO vo, UserDAO dao, HttpSession session) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("loginController");

        UserVO data=dao.getUser(vo);

        if(data!=null){
        	System.out.print("데이터있음");
        	session.setAttribute("userName", data.getName());
        	return "redirect:getBoardList.do";

        }
        else{
        	return "login.jsp";

        }
	}
	
	@RequestMapping(value ="/login.do", method = RequestMethod.GET)
	public String login2(@ModelAttribute("user")UserVO vo, UserDAO dao) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("loginController");

        UserVO data=dao.getUser(vo);

        if(data!=null){
        	System.out.print("데이터있음");
        	return "redirect:getBoardList.do";

        }
        else{
        	vo.setId("admin");
        	vo.setPassword("1234");
        	return "login.jsp";

        }
	}
	
	
	@RequestMapping(value = "/logout.do")
	public String logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		session.invalidate();
		return "redierct:login.jsp";
	}
	@RequestMapping(value = "/regist.do")
	public String insertRegist(UserVO vo, UserDAO dao) throws Exception {
		// TODO Auto-generated method stub
		
		UserVO data = dao.getUser(vo);

		if(data == null){
			dao.insertUser(vo);
			System.out.println("성공");
			return "redierct:login.jsp";
		}else{
			System.out.println("실패");
			return "redierct:regist.jsp";
		
		}
	}
	
	@RequestMapping(value = "getUserList.do")
	public ModelAndView getUserLisr(UserVO vo, UserDAO dao, ModelAndView mav) throws Exception {

		List<UserVO> userlist = dao.getUserList();

		mav.addObject("data", userlist);
		if (userlist != null) {
			mav.setViewName("getUserList.jsp");
			return mav;			
		} else {
			mav.setViewName("redierct:login.jsp");
			return mav;			

		}
	}
	
	
}
