package com.heo.view.board;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.heo.app.board.BoardService;
import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;

@Controller
@SessionAttributes("boardData")
public class BoardController {
	
	@Autowired
	private BoardService BoardService;
	
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo) throws Exception {
		
//		String title = request.getParameter("title");
//		String writer = request.getParameter("writer");
//		String content = request.getParameter("content");
//
//		vo.setTitle(title);
//		vo.setContent(content);
//		vo.setWriter(writer);
		MultipartFile uplodefile = vo.getUplodeFile();
		if(!uplodefile.isEmpty()) {
			String file = uplodefile.getOriginalFilename();
			System.out.println(file);
			uplodefile.transferTo(new File("C:\\Users\\82109\\Desktop\\eclipseworkspace"+file));
		}
		
		BoardService.insertBoard(vo);
//		redirect:
		return "getBoardList.do";
	}
	
	@ModelAttribute("resultMap")
	public HashMap<String, String> searchMap() {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("제목", "title");
		map.put("내용", "content");
		
		return map;
	}
	
	
	@RequestMapping("/getBoard.do")
	public String handleRequest(BoardVO vo, Model m) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("getBoardController");

		BoardVO v = BoardService.getBoard(vo);

		m.addAttribute("boardData", v);

		return "getBoard.jsp";
	}
	
	/*
	 * @RequestMapping(value = "/getBoardList.do") public String
	 * getBoardList(BoardVO vo, Model m) throws Exception {
	 * System.out.println("boardlist");
	 * 
	 * List<BoardVO> boardList = BoardService.getBoardList(vo);
	 * 
	 * // HttpSession session = request.getSession(); //
	 * session.setAttribute("data", boardList);
	 * 
	 * m.addAttribute("data", boardList);
	 * 
	 * return "getBoardList.jsp"; }
	 */
	@RequestMapping(value="/getBoardList.do")
	   public String getBoardList(BoardVO vo,Model m)  {
	      System.out.println("게시판 목록보기 컨트롤러+검색");
	      
	      if(vo.getSearch()==null) {
	         vo.setSearch("title");
	      }
	      if(vo.getSearchContent()==null) {
	         vo.setSearchContent("");
	      }

	      List<BoardVO> boardList=BoardService.getBoardList(vo);
	      
	      m.addAttribute("boardList", boardList);
	   
	      return "getBoardList.jsp";
	   }

	
	
	
	@RequestMapping(value = "/deleteBoard.do")
	public String handleRequest(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardService.deleteBoard(vo);
        
        System.out.println("deleteController");
        return "redirect:getBoardList.do";
	}
	@RequestMapping(value = "/update.do")
	public String update(@ModelAttribute("boardData")BoardVO vo) {
		System.out.println("update");
		System.out.println(vo.getWriter());
		BoardService.updateBoard(vo);
		
		return "redirect:getBoardList.do";
	}
	
	
	
}
