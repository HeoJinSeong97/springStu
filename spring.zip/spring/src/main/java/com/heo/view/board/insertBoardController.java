package com.heo.view.board;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;

//	POJO spring MVC에서 제공하는 Controller를 implements한 클래스는 POJO클래스xxx
//@Controller
public class insertBoardController{
	
	
//	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo, BoardDAO dao) throws Exception {
		
//		String title = request.getParameter("title");
//		String writer = request.getParameter("writer");
//		String content = request.getParameter("content");
//
//		vo.setTitle(title);
//		vo.setContent(content);
//		vo.setWriter(writer);

		dao.insertBoard(vo);
//		redirect:
		return "getBoardList.do";
	}
}
