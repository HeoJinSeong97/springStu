package com.heo.view.board;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



import com.heo.app.board.BoardVO;
import com.heo.app.board.impl.BoardDAO;
//@Controller
public class deleteBoardController{
	
//	@RequestMapping(value = "/deleteBoard.do")
	public String handleRequest(BoardVO vo, BoardDAO dao) throws Exception {
		// TODO Auto-generated method stub
        dao.deleteBoard(vo);
        
        System.out.println("deleteController");
        return "redirect:getBoardList.do";
	}
}
