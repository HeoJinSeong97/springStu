package coupling;

public interface Phone {
	public void powerOn();
	public void powerOff();
	public void voluemUp();
	public void voluemDown();
}
