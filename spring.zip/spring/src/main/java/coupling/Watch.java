package coupling;

public interface Watch {
	public void volumeUp();
	public void volumeDown();
	
}
