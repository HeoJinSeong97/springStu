package coupling;

public class BeanFactory {
	public Object getBean(String beanName) {
		if (beanName.equals("i")) {
			return new IPhone();
		}else if(beanName.equals("gal")) {
			return new GalPhone();
		}
		return null;
	}
}
