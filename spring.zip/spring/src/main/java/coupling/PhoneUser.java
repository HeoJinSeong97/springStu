package coupling;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class PhoneUser {
	public static void main(String[] args) {
		
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		
		Phone phone = (Phone)factory.getBean("phone");
		phone.powerOn();
		phone.voluemUp();
		phone.voluemDown();
		
//		Phone phone2 = (Phone)factory.getBean("galphone");
//		phone2.powerOn();
//		phone2.voluemUp();
//		phone2.voluemDown();
		
		factory.close();
		
//		BeanFactory bf = new BeanFactory();
//		
//		Phone phone = (Phone)bf.getBean("gal");
//		phone.powerOn();
//		phone.voluemUp();
//		�ʿ��� ��ü�� �����ϸ�, ��ü�� �����ϴ� ��ü�� BeanFactory�̴�.
	}
}
