package coupling;

import org.springframework.stereotype.Component;

@Component("aw")
public class AppleWatch implements Watch{
	
	public AppleWatch() {
		// TODO Auto-generated constructor stub
		System.out.println("���ÿ�ġ ������");
	}
	@Override
	public void volumeUp() {
		// TODO Auto-generated method stub
		System.out.println("AppleWatch Volume++");
	}

	@Override
	public void volumeDown() {
		// TODO Auto-generated method stub
		System.out.println("AppleWatch Volume--");
	}

}
