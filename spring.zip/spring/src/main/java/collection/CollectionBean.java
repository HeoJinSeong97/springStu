package collection;

import java.util.List;

public class CollectionBean {
	private List<String> dataList;

	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}
	
}
