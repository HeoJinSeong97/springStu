package collection;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import coupling.Phone;

public class Client {
	public static void main(String[] args) {
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		
		CollectionBean cb = (CollectionBean)factory.getBean("cb");
		List<String> data = cb.getDataList();
		System.out.println(data);

		
		factory.close();
	}
}
